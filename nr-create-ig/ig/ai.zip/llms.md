# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](downloads.md)

## Resources

### Bundles

* [86be429f-d9df-4810-a817-0e098b4483fd](Bundle-86be429f-d9df-4810-a817-0e098b4483fd.md)
* [edef0890-a41a-46f3-a5b6-ea5758f820e5](Bundle-edef0890-a41a-46f3-a5b6-ea5758f820e5.md)

### ConceptMaps

* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
