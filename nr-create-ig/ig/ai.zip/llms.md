# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](downloads.md)

## Resources

### Bundles

* [93b9690f-efa3-4a9e-8bee-e0783831a94e](Bundle-93b9690f-efa3-4a9e-8bee-e0783831a94e.md)

### ConceptMaps

* [ConceptMap - OID to URL for TRE_R38-SpecialiteOrdinale](ConceptMap-cm-oid-specialite-ordinale.md)
* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)
* [OID to URI Mapping for ANS terminologies](ConceptMap-oid2uri-ans.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
