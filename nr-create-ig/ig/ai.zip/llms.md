# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [Flux 01](st_flux1.md)
* [Specifications Techniques](specifications_techniques.md)
* [Téléchargements et usages](downloads.md)
* [Artifacts Summary](artifacts.md)
* [Vue d'ensemble](construction_des_flux.md)
* [Vue d'ensemble](sf1.md)
* [Historique des versions](change-log.md)
* [Flux 02](st_flux2.md)
* [Autres Ressources](autres_ressources.md)
* [Sécurité](securite.md)
* [Specifications Fonctionnelles](specifications_fonctionnelles.md)

## Resources

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping de CDA vers les FHIR Types (Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
