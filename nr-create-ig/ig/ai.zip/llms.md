# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](downloads.md)

## Resources

### Bundles

* [9c526a33-9ce9-4b13-891d-2c647c89769d](Bundle-9c526a33-9ce9-4b13-891d-2c647c89769d.md)
* [e6fdbbd6-0964-47c1-b971-7a1469d5ab81](Bundle-e6fdbbd6-0964-47c1-b971-7a1469d5ab81.md)

### ConceptMaps

* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
