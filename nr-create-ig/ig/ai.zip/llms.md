# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Artifacts Summary](artifacts.md)
* [Autres Ressources](autres_ressources.md)
* [Téléchargements et usages](downloads.md)

## Resources

### Bundles

* [2937bc70-0b09-4c9c-a395-4f088f0cd3ec](Bundle-2937bc70-0b09-4c9c-a395-4f088f0cd3ec.md)
* [8628f435-5674-4da4-beb5-433e9e2d25ab](Bundle-8628f435-5674-4da4-beb5-433e9e2d25ab.md)

### ConceptMaps

* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
