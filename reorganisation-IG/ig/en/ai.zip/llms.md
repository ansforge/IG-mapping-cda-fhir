# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR(en)

## Pages

* [Accueil](index.md)
* [Informations sur la traduction](translationinfo.md)
* [Artifacts Summary](artifacts.md)
* [Autres méthodes de mapping](outils-mapping.md)
* [Historique des versions](change-log.md)
* [Transformation FML](Transformation-FML.md)
* [Démarrage Matchbox](guide-demarrage.md)
* [Mécanismes de mapping](mecanismes-mapping.md)
* [Architecture de mapping](Architecture-de-mapping.md)

## Resources

### Bundles

* [fe569e1f-32d4-4ba4-b5ad-88082bf5470a](Bundle-fe569e1f-32d4-4ba4-b5ad-88082bf5470a.md)

### ConceptMaps

* [ConceptMap — CDA AD vers FHIR Address](ConceptMap-CdaADToAddressConceptMap.md)
* [ConceptMap — CDA BL vers FHIR boolean](ConceptMap-CdaBLToBooleanConceptMap.md)
* [ConceptMap — CDA CE/CS/CD vers FHIR code et CodeableConcept](ConceptMap-CdaCECSCDToCodeConceptMap.md)
* [ConceptMap — CDA EN/PN vers FHIR HumanName](ConceptMap-CdaENPNToHumanNameConceptMap.md)
* [ConceptMap — CDA II vers FHIR Identifier](ConceptMap-CdaIIToIdentifierConceptMap.md)
* [ConceptMap — CDA INT vers FHIR integer](ConceptMap-CdaINTToIntegerConceptMap.md)
* [ConceptMap — CDA IVL_TS vers FHIR Period et dateTime](ConceptMap-CdaIVL-TSToPeriodConceptMap.md)
* [ConceptMap — CDA PQ vers FHIR Quantity](ConceptMap-CdaPQToQuantityConceptMap.md)
* [ConceptMap — CDA RTO_PQ_PQ vers FHIR Ratio](ConceptMap-CdaRTO-PQ-PQToRatioConceptMap.md)
* [ConceptMap — CDA ST/ED/ON vers FHIR string](ConceptMap-CdaSTEDONToStringConceptMap.md)
* [ConceptMap — CDA TEL vers FHIR ContactPoint](ConceptMap-CdaTELToContactPointConceptMap.md)
* [ConceptMap — CDA TS vers FHIR instant, dateTime et date](ConceptMap-CdaTSToDateTimeConceptMap.md)
* [ConceptMap - OID to URL for TRE_R38-SpecialiteOrdinale](ConceptMap-cm-oid-specialite-ordinale.md)
* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)
* [OID to URI Mapping for ANS terminologies](ConceptMap-oid2uri-ans.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](ImplementationGuide-ans.fhir.fr.mappingcdafhir.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
