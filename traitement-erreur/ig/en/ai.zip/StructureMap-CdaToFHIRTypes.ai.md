# Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger) - Mapping CDA to FHIR (Preuve de concept) v0.1.0

## StructureMap: Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger) 

 
Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger) 



## Resource Content

```json
{
  "resourceType" : "StructureMap",
  "id" : "CdaToFHIRTypes",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/mappingcdafhir/StructureMap/CdaToFHIRTypes",
  "version" : "0.1.0",
  "name" : "CdaToFHIRTypes",
  "title" : "Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)",
  "status" : "draft",
  "date" : "2026-07-23T13:24:07+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "structure" : [{
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/ED|2.0.0-sd",
    "mode" : "source",
    "alias" : "ED"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/PN|2.0.0-sd",
    "mode" : "source",
    "alias" : "PN"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/II|2.0.0-sd",
    "mode" : "source",
    "alias" : "II"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/TS|2.0.0-sd",
    "mode" : "source",
    "alias" : "TS"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/CS|2.0.0-sd",
    "mode" : "source",
    "alias" : "CS"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/CE|2.0.0-sd",
    "mode" : "source",
    "alias" : "CE"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/ST|2.0.0-sd",
    "mode" : "source",
    "alias" : "ST"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/ON|2.0.0-sd",
    "mode" : "source",
    "alias" : "ON"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/EN|2.0.0-sd",
    "mode" : "source",
    "alias" : "EN"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/AD|2.0.0-sd",
    "mode" : "source",
    "alias" : "AD"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/TEL|2.0.0-sd",
    "mode" : "source",
    "alias" : "TEL"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/BL|2.0.0-sd",
    "mode" : "source",
    "alias" : "BL"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/IVL-TS|2.0.0-sd",
    "mode" : "source",
    "alias" : "IVL_TS"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/INT|2.0.0-sd",
    "mode" : "source",
    "alias" : "INT"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/CD|2.0.0-sd",
    "mode" : "source",
    "alias" : "CD"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/PQ|2.0.0-sd",
    "mode" : "source",
    "alias" : "PQ"
  },
  {
    "url" : "http://hl7.org/cda/stds/core/StructureDefinition/RTO-PQ-PQ|2.0.0-sd",
    "mode" : "source",
    "alias" : "RTO_PQ_PQ"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Identifier|4.0.1",
    "mode" : "target",
    "alias" : "Identifier"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/instant|4.0.1",
    "mode" : "target",
    "alias" : "instant"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/code|4.0.1",
    "mode" : "target",
    "alias" : "code"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/CodeableConcept|4.0.1",
    "mode" : "target",
    "alias" : "CodeableConcept"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Coding|4.0.1",
    "mode" : "target",
    "alias" : "Coding"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/string|4.0.1",
    "mode" : "target",
    "alias" : "string"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/HumanName|4.0.1",
    "mode" : "target",
    "alias" : "HumanName"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Address|4.0.1",
    "mode" : "target",
    "alias" : "Address"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/ContactPoint|4.0.1",
    "mode" : "target",
    "alias" : "ContactPoint"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/boolean|4.0.1",
    "mode" : "target",
    "alias" : "boolean"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Period|4.0.1",
    "mode" : "target",
    "alias" : "Period"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/integer|4.0.1",
    "mode" : "target",
    "alias" : "integer"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/dateTime|4.0.1",
    "mode" : "target",
    "alias" : "dateTime"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/date|4.0.1",
    "mode" : "target",
    "alias" : "date"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Quantity|4.0.1",
    "mode" : "target",
    "alias" : "Quantity"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/Ratio|4.0.1",
    "mode" : "target",
    "alias" : "Ratio"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/DomainResource|4.0.1",
    "mode" : "target",
    "alias" : "DomainResource"
  }],
  "group" : [{
    "name" : "Any",
    "typeMode" : "none",
    "documentation" : "Groupe générique de base (Sert de groupe parent pour les autres mappings)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "base",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "II",
    "extends" : "Any",
    "typeMode" : "none",
    "documentation" : "Mapping CDA II vers FHIR Identifier\nII = Identifiant CDA\nIdentifier = Identifiant FHIR",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "root1",
      "source" : [{
        "context" : "src",
        "element" : "root",
        "variable" : "r",
        "condition" : "src.extension.exists()"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "append",
        "parameter" : [{
          "valueString" : "urn:oid:"
        },
        {
          "valueId" : "r"
        }]
      }]
    },
    {
      "name" : "rootuuid",
      "source" : [{
        "context" : "src",
        "element" : "root",
        "variable" : "r",
        "condition" : "src.extension.empty() and src.root.matches('[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "urn:ietf:rfc:3986"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "evaluate",
        "parameter" : [{
          "valueString" : "'urn:uuid:' + %r.lower()"
        }]
      }]
    },
    {
      "name" : "rootoid",
      "source" : [{
        "context" : "src",
        "element" : "root",
        "variable" : "r",
        "condition" : "src.extension.empty() and src.root.contains('.')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "urn:ietf:rfc:3986"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "append",
        "parameter" : [{
          "valueString" : "urn:oid:"
        },
        {
          "valueId" : "r"
        }]
      }]
    },
    {
      "name" : "extension",
      "source" : [{
        "context" : "src",
        "element" : "extension",
        "variable" : "e"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "e"
        }]
      }]
    },
    {
      "name" : "assigningAuthorityName",
      "source" : [{
        "context" : "src",
        "element" : "assigningAuthorityName",
        "variable" : "s"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "assigner",
        "variable" : "a"
      },
      {
        "context" : "a",
        "contextType" : "variable",
        "element" : "display",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "s"
        }]
      }],
      "documentation" : "there's no equivalent for displayable in FHIR - and it probably will never matter, but if it does, it might map to Identifier.use."
    },
    {
      "name" : "extension",
      "source" : [{
        "context" : "src",
        "element" : "displayable",
        "variable" : "displayable"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "extension",
        "variable" : "ext"
      }],
      "rule" : [{
        "name" : "url",
        "source" : [{
          "context" : "displayable"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "url",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://hl7.org/fhir/cdaStructureDefinition/extension-displayable"
          }]
        }]
      },
      {
        "name" : "value",
        "source" : [{
          "context" : "displayable",
          "element" : "value",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "v"
          },
          {
            "valueString" : "string"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "INT",
    "extends" : "Any",
    "typeMode" : "types",
    "documentation" : "Mapping CDA INT vers FHIR integer\nINT = entier CDA\ninteger = entier FHIR",
    "input" : [{
      "name" : "src",
      "type" : "INT",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "integer",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "integer",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "v"
        }]
      }]
    }]
  },
  {
    "name" : "TemplateID",
    "typeMode" : "none",
    "documentation" : "Mapping des templateId CDA (Les templateId sont conservés dans des extensions FHIR)",
    "input" : [{
      "name" : "template",
      "type" : "II",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "DomainResource",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "templateId",
      "source" : [{
        "context" : "template"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "extension",
        "variable" : "ext"
      }],
      "rule" : [{
        "name" : "url",
        "source" : [{
          "context" : "template"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "url",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://hl7.org/cda/stds/core/StructureDefinition/templateID"
          }]
        }]
      },
      {
        "name" : "value",
        "source" : [{
          "context" : "template"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "value",
          "variable" : "value",
          "transform" : "create",
          "parameter" : [{
            "valueString" : "Identifier"
          }]
        }],
        "rule" : [{
          "name" : "root1",
          "source" : [{
            "context" : "template",
            "element" : "root",
            "variable" : "r",
            "condition" : "template.extension.exists()"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "system",
            "transform" : "append",
            "parameter" : [{
              "valueString" : "urn:oid:"
            },
            {
              "valueId" : "r"
            }]
          }]
        },
        {
          "name" : "rootuuid",
          "source" : [{
            "context" : "template",
            "element" : "root",
            "variable" : "r",
            "condition" : "template.extension.empty() and template.root.matches('[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}')"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "system",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "urn:ietf:rfc:3986"
            }]
          },
          {
            "context" : "value",
            "contextType" : "variable",
            "element" : "value",
            "transform" : "evaluate",
            "parameter" : [{
              "valueString" : "'urn:uuid:' + %r.lower()"
            }]
          }]
        },
        {
          "name" : "rootoid",
          "source" : [{
            "context" : "template",
            "element" : "root",
            "variable" : "r",
            "condition" : "template.extension.empty() and template.root.contains('.')"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "system",
            "transform" : "copy",
            "parameter" : [{
              "valueString" : "urn:ietf:rfc:3986"
            }]
          },
          {
            "context" : "value",
            "contextType" : "variable",
            "element" : "value",
            "transform" : "append",
            "parameter" : [{
              "valueString" : "urn:oid:"
            },
            {
              "valueId" : "r"
            }]
          }]
        },
        {
          "name" : "extension",
          "source" : [{
            "context" : "template",
            "element" : "extension",
            "variable" : "e"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "value",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "e"
            }]
          }]
        },
        {
          "name" : "assigningAuthorityName",
          "source" : [{
            "context" : "template",
            "element" : "assigningAuthorityName",
            "variable" : "s"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "assigner",
            "variable" : "a"
          },
          {
            "context" : "a",
            "contextType" : "variable",
            "element" : "display",
            "transform" : "copy",
            "parameter" : [{
              "valueId" : "s"
            }]
          }]
        },
        {
          "name" : "extension",
          "source" : [{
            "context" : "template",
            "element" : "displayable",
            "variable" : "displayable"
          }],
          "target" : [{
            "context" : "value",
            "contextType" : "variable",
            "element" : "extension",
            "variable" : "valueExtension"
          }],
          "rule" : [{
            "name" : "url",
            "source" : [{
              "context" : "displayable"
            }],
            "target" : [{
              "context" : "valueExtension",
              "contextType" : "variable",
              "element" : "url",
              "transform" : "copy",
              "parameter" : [{
                "valueString" : "http://hl7.org/fhir/cdaStructureDefinition/extension-displayable"
              }]
            }]
          },
          {
            "name" : "value",
            "source" : [{
              "context" : "displayable",
              "element" : "value",
              "variable" : "v"
            }],
            "target" : [{
              "context" : "valueExtension",
              "contextType" : "variable",
              "element" : "value",
              "transform" : "cast",
              "parameter" : [{
                "valueId" : "v"
              },
              {
                "valueString" : "string"
              }]
            }]
          }]
        }]
      }]
    }]
  },
  {
    "name" : "Negation",
    "typeMode" : "none",
    "documentation" : "Mapping du negationIndicator CDA (La négation CDA est représentée comme modifierExtension FHIR)",
    "input" : [{
      "name" : "negation",
      "type" : "BL",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "DomainResource",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "negation",
      "source" : [{
        "context" : "negation"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "modifierExtension",
        "variable" : "ext"
      }],
      "rule" : [{
        "name" : "url",
        "source" : [{
          "context" : "negation"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "url",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://hl7.org/cda/stds/core/StructureDefinition/negationIndicator"
          }]
        }]
      },
      {
        "name" : "value",
        "source" : [{
          "context" : "negation",
          "variable" : "neg"
        }],
        "target" : [{
          "context" : "ext",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "create",
          "parameter" : [{
            "valueString" : "boolean"
          }]
        },
        {
          "context" : "ext",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "neg"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "TSInstant",
    "extends" : "Any",
    "typeMode" : "none",
    "documentation" : "Mapping CDA TS vers FHIR instant (TS = timestamp CDA)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "value",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "cast",
        "parameter" : [{
          "valueId" : "v"
        },
        {
          "valueString" : "string"
        }]
      }]
    }]
  },
  {
    "name" : "TSDateTime",
    "extends" : "TSInstant",
    "typeMode" : "none",
    "documentation" : "Mapping CDA TS vers FHIR dateTime (Hérite du mapping TSInstant)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "TSDate",
    "extends" : "TSInstant",
    "typeMode" : "none",
    "documentation" : "Mapping CDA TS vers FHIR date (Hérite aussi du mapping TSInstant)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "IVLTSPeriod",
    "extends" : "Any",
    "typeMode" : "none",
    "documentation" : "Mapping CDA IVL_TS vers FHIR Period\nIVL_TS = intervalle de temps CDA\nPeriod = période FHIR avec start et end",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "low",
      "source" : [{
        "context" : "src",
        "element" : "low",
        "variable" : "low"
      }],
      "rule" : [{
        "name" : "start",
        "source" : [{
          "context" : "low",
          "element" : "value",
          "variable" : "value"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "start",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "value"
          },
          {
            "valueString" : "dateTime"
          }]
        }]
      }]
    },
    {
      "name" : "high",
      "source" : [{
        "context" : "src",
        "element" : "high",
        "variable" : "high"
      }],
      "rule" : [{
        "name" : "end",
        "source" : [{
          "context" : "high",
          "element" : "value",
          "variable" : "value"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "end",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "value"
          },
          {
            "valueString" : "dateTime"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "IVLTSDateTime",
    "extends" : "Any",
    "typeMode" : "types",
    "documentation" : "Mapping CDA IVL_TS vers FHIR dateTime (On utilise uniquement la borne basse low)",
    "input" : [{
      "name" : "src",
      "type" : "IVL_TS",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "dateTime",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "low",
      "source" : [{
        "context" : "src",
        "element" : "low",
        "variable" : "low"
      }],
      "rule" : [{
        "name" : "value",
        "source" : [{
          "context" : "low",
          "element" : "value",
          "variable" : "value"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "value"
          },
          {
            "valueString" : "string"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "STstring",
    "typeMode" : "none",
    "documentation" : "Mapping CDA ST vers FHIR string (ST = texte simple CDA)",
    "input" : [{
      "name" : "src",
      "type" : "ST",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "string",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "value",
      "source" : [{
        "context" : "src",
        "variable" : "v"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "cast",
        "parameter" : [{
          "valueId" : "v"
        },
        {
          "valueString" : "string"
        }]
      }]
    }]
  },
  {
    "name" : "EDstring",
    "extends" : "STstring",
    "typeMode" : "types",
    "documentation" : "Mapping CDA ED vers FHIR string (ED hérite du comportement de STstring)",
    "input" : [{
      "name" : "src",
      "type" : "ED",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "string",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "ONstring",
    "extends" : "STstring",
    "typeMode" : "types",
    "documentation" : "Mapping CDA ON vers FHIR string (ON = Organization Name CDA)",
    "input" : [{
      "name" : "src",
      "type" : "ON",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "string",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "CSCode",
    "typeMode" : "none",
    "documentation" : "Mapping CDA CS vers FHIR code (CS = coded simple CDA)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "code",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "c"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "cast",
        "parameter" : [{
          "valueId" : "c"
        },
        {
          "valueString" : "string"
        }]
      }]
    }]
  },
  {
    "name" : "CECode",
    "extends" : "CSCode",
    "typeMode" : "types",
    "documentation" : "Mapping CDA CE vers FHIR code (CE hérite du mapping CSCode)",
    "input" : [{
      "name" : "src",
      "type" : "CE",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "code",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "CDCode",
    "extends" : "CSCode",
    "typeMode" : "types",
    "documentation" : "Mapping CDA CD vers FHIR code (CD hérite du mapping CSCode)",
    "input" : [{
      "name" : "src",
      "type" : "CD",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "code",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "CECodeableConcept",
    "typeMode" : "none",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "originalText",
      "source" : [{
        "context" : "src",
        "element" : "originalText",
        "variable" : "originalText"
      }],
      "rule" : [{
        "name" : "originalTextReference",
        "source" : [{
          "context" : "originalText",
          "element" : "reference",
          "variable" : "ref"
        }],
        "rule" : [{
          "name" : "textFromOriginalTextReference",
          "source" : [{
            "context" : "ref",
            "element" : "value",
            "variable" : "value"
          }],
          "target" : [{
            "context" : "tgt",
            "contextType" : "variable",
            "element" : "text",
            "transform" : "cast",
            "parameter" : [{
              "valueId" : "value"
            },
            {
              "valueString" : "string"
            }]
          }]
        }]
      }]
    },
    {
      "name" : "code",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "coding",
        "variable" : "coding"
      }],
      "rule" : [{
        "name" : "code",
        "source" : [{
          "context" : "src",
          "element" : "code",
          "variable" : "code"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "code",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "code"
          },
          {
            "valueString" : "code"
          }]
        }]
      },
      {
        "name" : "systemLoinc",
        "source" : [{
          "context" : "src",
          "element" : "codeSystem",
          "variable" : "system",
          "condition" : "system = '2.16.840.1.113883.6.1'"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://loinc.org"
          }]
        }]
      },
      {
        "name" : "systemSnomed",
        "source" : [{
          "context" : "src",
          "element" : "codeSystem",
          "variable" : "system",
          "condition" : "system = '2.16.840.1.113883.6.96'"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://snomed.info/sct"
          }]
        }]
      },
      {
        "name" : "systemActCode",
        "source" : [{
          "context" : "src",
          "element" : "codeSystem",
          "variable" : "system",
          "condition" : "system = '2.16.840.1.113883.5.4'"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://terminology.hl7.org/CodeSystem/v3-ActCode"
          }]
        }]
      },
      {
        "name" : "systemTREA02",
        "source" : [{
          "context" : "src",
          "element" : "codeSystem",
          "variable" : "system",
          "condition" : "system = '1.2.250.1.213.1.1.4.5'"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "https://mos.esante.gouv.fr/NOS/TRE_A02-ProfessionSavFaire-CISIS/FHIR/TRE-A02-ProfessionSavFaire-CISIS"
          }]
        }]
      },
      {
        "name" : "systemFallback",
        "source" : [{
          "context" : "src",
          "element" : "codeSystem",
          "variable" : "system",
          "condition" : "(system != '2.16.840.1.113883.6.1') and (system != '2.16.840.1.113883.6.96') and (system != '2.16.840.1.113883.5.4') and (system != '1.2.250.1.213.1.1.4.5')"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "append",
          "parameter" : [{
            "valueString" : "urn:oid:"
          },
          {
            "valueId" : "system"
          }]
        }]
      },
      {
        "name" : "display",
        "source" : [{
          "context" : "src",
          "element" : "displayName",
          "variable" : "display"
        }],
        "target" : [{
          "context" : "coding",
          "contextType" : "variable",
          "element" : "display",
          "transform" : "cast",
          "parameter" : [{
            "valueId" : "display"
          },
          {
            "valueString" : "string"
          }]
        }]
      }]
    }]
  },
  {
    "name" : "CSCodeableConcept",
    "extends" : "CECodeableConcept",
    "typeMode" : "types",
    "documentation" : "Mapping CDA CS vers FHIR CodeableConcept (CS réutilise la logique CECodeableConcept)",
    "input" : [{
      "name" : "src",
      "type" : "CS",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "CodeableConcept",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "CDCodeableConcept",
    "extends" : "CECodeableConcept",
    "typeMode" : "none",
    "documentation" : "Mapping CDA CD vers FHIR CodeableConcept (CD réutilise la logique CECodeableConcept)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "CDCoding",
    "typeMode" : "none",
    "documentation" : "Mapping CDA CD / CE vers FHIR Coding (Utilisé quand la cible FHIR attend directement un Coding, par exemple Encounter.class)",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Coding",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "code",
      "source" : [{
        "context" : "src",
        "element" : "code",
        "variable" : "code"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "code",
        "transform" : "cast",
        "parameter" : [{
          "valueId" : "code"
        },
        {
          "valueString" : "code"
        }]
      }]
    },
    {
      "name" : "systemLoinc",
      "source" : [{
        "context" : "src",
        "element" : "codeSystem",
        "variable" : "system",
        "condition" : "system = '2.16.840.1.113883.6.1'"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "http://loinc.org"
        }]
      }]
    },
    {
      "name" : "systemSnomed",
      "source" : [{
        "context" : "src",
        "element" : "codeSystem",
        "variable" : "system",
        "condition" : "system = '2.16.840.1.113883.6.96'"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "http://snomed.info/sct"
        }]
      }]
    },
    {
      "name" : "systemActCode",
      "source" : [{
        "context" : "src",
        "element" : "codeSystem",
        "variable" : "system",
        "condition" : "system = '2.16.840.1.113883.5.4'"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "http://terminology.hl7.org/CodeSystem/v3-ActCode"
        }]
      }]
    },
    {
      "name" : "systemTREA02",
      "source" : [{
        "context" : "src",
        "element" : "codeSystem",
        "variable" : "system",
        "condition" : "system = '1.2.250.1.213.1.1.4.5'"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "https://mos.esante.gouv.fr/NOS/TRE_A02-ProfessionSavFaire-CISIS/FHIR/TRE-A02-ProfessionSavFaire-CISIS"
        }]
      }]
    },
    {
      "name" : "systemFallback",
      "source" : [{
        "context" : "src",
        "element" : "codeSystem",
        "variable" : "system",
        "condition" : "(system != '2.16.840.1.113883.6.1') and (system != '2.16.840.1.113883.6.96') and (system != '2.16.840.1.113883.5.4') and (system != '1.2.250.1.213.1.1.4.5')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "append",
        "parameter" : [{
          "valueString" : "urn:oid:"
        },
        {
          "valueId" : "system"
        }]
      }]
    },
    {
      "name" : "display",
      "source" : [{
        "context" : "src",
        "element" : "displayName",
        "variable" : "display"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "display",
        "transform" : "cast",
        "parameter" : [{
          "valueId" : "display"
        },
        {
          "valueString" : "string"
        }]
      }]
    }]
  },
  {
    "name" : "ENHumanName",
    "typeMode" : "none",
    "documentation" : "Mapping CDA EN vers FHIR HumanName\nEN = Entity Name CDA\nHumanName = nom humain FHIR",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "item",
      "source" : [{
        "context" : "src",
        "element" : "item",
        "variable" : "item"
      }],
      "rule" : [{
        "name" : "family",
        "source" : [{
          "context" : "item",
          "element" : "family",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "family",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "given",
        "source" : [{
          "context" : "item",
          "element" : "given",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "given",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "prefix",
        "source" : [{
          "context" : "item",
          "element" : "prefix",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "prefix",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "suffix",
        "source" : [{
          "context" : "item",
          "element" : "suffix",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "suffix",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      }]
    },
    {
      "name" : "validTime",
      "source" : [{
        "context" : "src",
        "element" : "validTime",
        "variable" : "validTime"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "period",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "validTime"
        }]
      }]
    }]
  },
  {
    "name" : "PNHumanName",
    "extends" : "ENHumanName",
    "typeMode" : "types",
    "documentation" : "Mapping CDA PN vers FHIR HumanName\nPN = Person Name CDA\nPN hérite du mapping ENHumanName",
    "input" : [{
      "name" : "src",
      "type" : "PN",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "HumanName",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "inherit",
      "source" : [{
        "context" : "src"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable"
      }]
    }]
  },
  {
    "name" : "ADAddress",
    "typeMode" : "none",
    "documentation" : "Mapping CDA AD vers FHIR Address\nAD = adresse CDA\nAddress = adresse FHIR",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "item",
      "source" : [{
        "context" : "src",
        "element" : "item",
        "variable" : "item"
      }],
      "rule" : [{
        "name" : "country",
        "source" : [{
          "context" : "item",
          "element" : "country",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "country",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "state",
        "source" : [{
          "context" : "item",
          "element" : "state",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "state",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "county",
        "source" : [{
          "context" : "item",
          "element" : "county",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "district",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "city",
        "source" : [{
          "context" : "item",
          "element" : "city",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "city",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "postalCode",
        "source" : [{
          "context" : "item",
          "element" : "postalCode",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "postalCode",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "streetAddressLine",
        "source" : [{
          "context" : "item",
          "element" : "streetAddressLine",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "line",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "streetName",
        "source" : [{
          "context" : "item",
          "element" : "streetName",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "line",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      },
      {
        "name" : "houseNumber",
        "source" : [{
          "context" : "item",
          "element" : "houseNumber",
          "variable" : "v"
        }],
        "target" : [{
          "context" : "tgt",
          "contextType" : "variable",
          "element" : "line",
          "transform" : "evaluate",
          "parameter" : [{
            "valueString" : "%v.xmlText"
          }]
        }]
      }]
    },
    {
      "name" : "useablePeriod",
      "source" : [{
        "context" : "src",
        "element" : "useablePeriod",
        "variable" : "useablePeriod"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "period",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "useablePeriod"
        }]
      }]
    }]
  },
  {
    "name" : "TELContactPoint",
    "typeMode" : "none",
    "documentation" : "Mapping CDA TEL vers FHIR ContactPoint\nTEL = téléphone/email/url CDA\nContactPoint = moyen de contact FHIR",
    "input" : [{
      "name" : "src",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "valuetel",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v",
        "condition" : "(src.value.startsWith('tel:'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "evaluate",
        "parameter" : [{
          "valueString" : "%v.substring(4)"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "phone"
        }]
      }]
    },
    {
      "name" : "valuefax",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v",
        "condition" : "(src.value.startsWith('fax:'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "evaluate",
        "parameter" : [{
          "valueString" : "%v.substring(4)"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "fax"
        }]
      }]
    },
    {
      "name" : "valuemail",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v",
        "condition" : "(src.value.startsWith('mailto:'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "evaluate",
        "parameter" : [{
          "valueString" : "%v.substring(7)"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "email"
        }]
      }]
    },
    {
      "name" : "valuehttp",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "v",
        "condition" : "(src.value.startsWith('http:'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "evaluate",
        "parameter" : [{
          "valueString" : "%v.substring(5)"
        }]
      },
      {
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "url"
        }]
      }]
    },
    {
      "name" : "usehome",
      "source" : [{
        "context" : "src",
        "element" : "use",
        "condition" : "(src.use.startsWith('H'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "use",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "home"
        }]
      }]
    },
    {
      "name" : "usework",
      "source" : [{
        "context" : "src",
        "element" : "use",
        "condition" : "((src.use = 'WP') or (src.use = 'DIR') or (src.use = 'PUB'))"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "use",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "work"
        }]
      }]
    },
    {
      "name" : "usebad",
      "source" : [{
        "context" : "src",
        "element" : "use",
        "condition" : "(src.use = 'BAD')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "use",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "old"
        }]
      }]
    },
    {
      "name" : "usetmp",
      "source" : [{
        "context" : "src",
        "element" : "use",
        "condition" : "(src.use = 'TMP')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "use",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "temp"
        }]
      }]
    },
    {
      "name" : "usemobile",
      "source" : [{
        "context" : "src",
        "element" : "use",
        "condition" : "(src.use = 'MC')"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "use",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "mobile"
        }]
      }]
    },
    {
      "name" : "useablePeriod",
      "source" : [{
        "context" : "src",
        "element" : "useablePeriod",
        "variable" : "useablePeriod"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "period",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "useablePeriod"
        }]
      }],
      "documentation" : "use: for src.use as c make tgt.use = translate(c, 'http://hl7.org/fhir/ConceptMap/cm-telecom-use-v3', 'code')"
    }]
  },
  {
    "name" : "PQQuantity",
    "typeMode" : "none",
    "documentation" : "Mapping CDA PQ vers FHIR Quantity\nPQ = quantité physique CDA\nQuantity = quantité FHIR",
    "input" : [{
      "name" : "src",
      "type" : "PQ",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Quantity",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "unit",
      "source" : [{
        "context" : "src",
        "element" : "unit",
        "variable" : "unit"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "unit",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "unit"
        }]
      }]
    },
    {
      "name" : "unit",
      "source" : [{
        "context" : "src",
        "element" : "unit",
        "variable" : "unit"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "code",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "unit"
        }]
      }]
    },
    {
      "name" : "unit",
      "source" : [{
        "context" : "src",
        "element" : "unit",
        "variable" : "unit"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "system",
        "transform" : "copy",
        "parameter" : [{
          "valueString" : "http://unitsofmeasure.org"
        }]
      }]
    },
    {
      "name" : "value",
      "source" : [{
        "context" : "src",
        "element" : "value",
        "variable" : "value"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "value",
        "transform" : "copy",
        "parameter" : [{
          "valueId" : "value"
        }]
      }]
    }]
  },
  {
    "name" : "RTOPQPQRatio",
    "typeMode" : "none",
    "documentation" : "Mapping CDA RTO_PQ_PQ vers FHIR Ratio\nRTO_PQ_PQ = ratio CDA composé d’un numérateur et d’un dénominateur\nRatio = ratio FHIR",
    "input" : [{
      "name" : "src",
      "type" : "RTO_PQ_PQ",
      "mode" : "source"
    },
    {
      "name" : "tgt",
      "type" : "Ratio",
      "mode" : "target"
    }],
    "rule" : [{
      "name" : "numerator",
      "source" : [{
        "context" : "src",
        "element" : "numerator",
        "variable" : "numerator"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "numerator",
        "variable" : "targetNumerator"
      }],
      "rule" : [{
        "name" : "unit",
        "source" : [{
          "context" : "numerator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetNumerator",
          "contextType" : "variable",
          "element" : "unit",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "unit"
          }]
        }]
      },
      {
        "name" : "unit",
        "source" : [{
          "context" : "numerator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetNumerator",
          "contextType" : "variable",
          "element" : "code",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "unit"
          }]
        }]
      },
      {
        "name" : "unit",
        "source" : [{
          "context" : "numerator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetNumerator",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://unitsofmeasure.org"
          }]
        }]
      },
      {
        "name" : "value",
        "source" : [{
          "context" : "numerator",
          "element" : "value",
          "variable" : "value"
        }],
        "target" : [{
          "context" : "targetNumerator",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "value"
          }]
        }]
      }]
    },
    {
      "name" : "denominator",
      "source" : [{
        "context" : "src",
        "element" : "denominator",
        "variable" : "denominator"
      }],
      "target" : [{
        "context" : "tgt",
        "contextType" : "variable",
        "element" : "denominator",
        "variable" : "targetDenominator"
      }],
      "rule" : [{
        "name" : "unit",
        "source" : [{
          "context" : "denominator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetDenominator",
          "contextType" : "variable",
          "element" : "unit",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "unit"
          }]
        }]
      },
      {
        "name" : "unit",
        "source" : [{
          "context" : "denominator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetDenominator",
          "contextType" : "variable",
          "element" : "code",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "unit"
          }]
        }]
      },
      {
        "name" : "unit",
        "source" : [{
          "context" : "denominator",
          "element" : "unit",
          "variable" : "unit"
        }],
        "target" : [{
          "context" : "targetDenominator",
          "contextType" : "variable",
          "element" : "system",
          "transform" : "copy",
          "parameter" : [{
            "valueString" : "http://unitsofmeasure.org"
          }]
        }]
      },
      {
        "name" : "value",
        "source" : [{
          "context" : "denominator",
          "element" : "value",
          "variable" : "value"
        }],
        "target" : [{
          "context" : "targetDenominator",
          "contextType" : "variable",
          "element" : "value",
          "transform" : "copy",
          "parameter" : [{
            "valueId" : "value"
          }]
        }]
      }]
    }]
  }]
}

```
