# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [null - TTL Representation](Binary-CSE-MDE2023.01.ttl.md)
* [null - XML Representation](Binary-CSE-MDE2023.01.xml.md)
* [null - JSON Representation](Binary-CSE-MDE2023.01.json.md)
* [Outils de Mapping](outils-mapping.md)
* [Initiatives internationales](initiatives-internationales.md)
* [Guide de démarrage](guide-demarrage.md)
* [Artifacts Summary](artifacts.md)
* [Mapping CDA vers FHIR](mapping-cda-fhir.md)
* [Mécanisme du Mapping](mapping-mechanisms.md)
* [](Binary-CSE-MDE2023.01.md)
* [Historique des versions](change-log.md)
* [](Binary-CSE-MDE2023.01.change.history.md)

## Resources

### Bundles

* [fe569e1f-32d4-4ba4-b5ad-88082bf5470a](Bundle-fe569e1f-32d4-4ba4-b5ad-88082bf5470a.md)

### ConceptMaps

* [ConceptMap - OID to URL for TRE_R38-SpecialiteOrdinale](ConceptMap-cm-oid-specialite-ordinale.md)
* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)
* [OID to URI Mapping for ANS terminologies](ConceptMap-oid2uri-ans.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
