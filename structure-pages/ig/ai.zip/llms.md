# ans.fhir.fr.mappingcdafhir#0.1.0: POC - Mapping CDA to FHIR

## Pages

* [Accueil](index.md)
* [null - TTL Representation](Binary-CSE-MDE2023.01.ttl.md)
* [null - XML Representation](Binary-CSE-MDE2023.01.xml.md)
* [null - JSON Representation](Binary-CSE-MDE2023.01.json.md)
* [Artifacts Summary](artifacts.md)
* [Téléchargements et usages](downloads.md)
* [Autres Ressources](autres_ressources.md)
* [](Binary-CSE-MDE2023.01.md)
* [Historique des versions](change-log.md)
* [](Binary-CSE-MDE2023.01.change.history.md)

## Resources

### Bundles

* [fe569e1f-32d4-4ba4-b5ad-88082bf5470a](Bundle-fe569e1f-32d4-4ba4-b5ad-88082bf5470a.md)

### ConceptMaps

* [ConceptMap — CDA AD → FHIR Address](ConceptMap-CdaToAddressConceptMap.md)
* [ConceptMap — CDA BL → FHIR boolean / negation](ConceptMap-CdaToBooleanConceptMap.md)
* [ConceptMap — CDA ClinicalDocument → FHIR Bundle](ConceptMap-CdaToBundleConceptMap.md)
* [ConceptMap — CDA CE/CS/CD → FHIR code/CodeableConcept](ConceptMap-CdaToCodeConceptMap.md)
* [ConceptMap — CDA ClinicalDocument → FHIR Composition](ConceptMap-CdaToCompositionConceptMap.md)
* [ConceptMap — CDA TEL → FHIR ContactPoint](ConceptMap-CdaToContactPointConceptMap.md)
* [ConceptMap — CDA TS → FHIR instant/dateTime/date](ConceptMap-CdaToDateTimeConceptMap.md)
* [ConceptMap — CDA EncompassingEncounter → FHIR Encounter](ConceptMap-CdaToEncounterConceptMap.md)
* [ConceptMap — CDA EN/PN → FHIR HumanName](ConceptMap-CdaToHumanNameConceptMap.md)
* [ConceptMap — CDA II → FHIR Identifier](ConceptMap-CdaToIdentifierConceptMap.md)
* [ConceptMap — CDA INT → FHIR integer](ConceptMap-CdaToIntegerConceptMap.md)
* [ConceptMap — CDA HealthCareFacility → FHIR Location](ConceptMap-CdaToLocationConceptMap.md)
* [ConceptMap — CDA CustodianOrganization → FHIR Organization](ConceptMap-CdaToOrganisationConceptMap.md)
* [ConceptMap — CDA PatientRole → FHIR Patient](ConceptMap-CdaToPatientConceptMap.md)
* [ConceptMap — CDA IVL_TS → FHIR Period/dateTime](ConceptMap-CdaToPeriodConceptMap.md)
* [ConceptMap — CDA AssignedAuthor → FHIR Practitioner](ConceptMap-CdaToPractitionerConceptMap.md)
* [ConceptMap — CDA PQ → FHIR Quantity](ConceptMap-CdaToQuantityConceptMap.md)
* [ConceptMap — CDA RTO_PQ_PQ → FHIR Ratio](ConceptMap-CdaToRatioConceptMap.md)
* [ConceptMap — CDA ST/ED/ON → FHIR string](ConceptMap-CdaToStringConceptMap.md)
* [ConceptMap - OID to URL for TRE_R38-SpecialiteOrdinale](ConceptMap-cm-oid-specialite-ordinale.md)
* [CDA to FHIR Administrative Gender Mapping](ConceptMap-cm-v3-administrative-gender.md)
* [OID to URI Mapping for ANS terminologies](ConceptMap-oid2uri-ans.md)

### ImplementationGuides

* [POC - Mapping CDA to FHIR](index.md)

### StructureMaps

* [Mapping CSE-MDE vers FHIR Bundle - Contexte Français](StructureMap-CdaFrMDEToBundle.md)
* [Mapping de CDAFr vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaFrToBundle.md)
* [Mapping de CDA vers FHIR Bundle (A partir des sources de Oliver Egger)](StructureMap-CdaToBundle.md)
* [Mapping de CDA vers les FHIR Types (A partir des sources de Oliver Egger)](StructureMap-CdaToFHIRTypes.md)
