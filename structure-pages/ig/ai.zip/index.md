# Accueil - POC - Mapping CDA to FHIR v0.1.0

* [**Table of Contents**](toc.md)
* **Accueil**

## Accueil

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/mappingcdafhir/ImplementationGuide/ans.fhir.fr.mappingcdafhir | *Version*:0.1.0 |
| Draft as of 2026-03-26 | *Computable Name*:CDA2FHIRMAP |

