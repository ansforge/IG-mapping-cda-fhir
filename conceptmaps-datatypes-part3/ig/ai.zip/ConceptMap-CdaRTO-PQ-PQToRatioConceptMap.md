# ConceptMap — CDA RTO_PQ_PQ vers FHIR Ratio - POC - Mapping CDA to FHIR v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ConceptMap — CDA RTO_PQ_PQ vers FHIR Ratio**

## ConceptMap: ConceptMap — CDA RTO_PQ_PQ vers FHIR Ratio (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/mappingcdafhir/ConceptMap/DataTypes/CdaRTOPQPQToFHIR | *Version*:0.1.0 |
| Draft as of 2026-04-30 | *Computable Name*:CdaRTOPQPQToFHIR |

 
Correspondances documentaires entre le datatype CDA RTO_PQ_PQ et le datatype FHIR Ratio. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "CdaRTO-PQ-PQToRatioConceptMap",
  "url" : "https://interop.esante.gouv.fr/ig/fhir/mappingcdafhir/ConceptMap/DataTypes/CdaRTOPQPQToFHIR",
  "version" : "0.1.0",
  "name" : "CdaRTOPQPQToFHIR",
  "title" : "ConceptMap — CDA RTO_PQ_PQ vers FHIR Ratio",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-04-30T10:20:46+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Correspondances documentaires entre le datatype CDA RTO_PQ_PQ et le datatype FHIR Ratio.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "FRANCE"
    }]
  }],
  "group" : [{
    "source" : "http://hl7.org/cda/stds/core/StructureDefinition/RTO_PQ_PQ",
    "target" : "http://hl7.org/fhir/StructureDefinition/Ratio",
    "element" : [{
      "code" : "RTO_PQ_PQ.numerator",
      "display" : "RTO_PQ_PQ.numerator",
      "target" : [{
        "code" : "Ratio.numerator",
        "display" : "Ratio.numerator",
        "equivalence" : "relatedto",
        "comment" : "Le numérateur CDA est converti en Quantity via le mapping PQ -> Quantity, puis affecté à Ratio.numerator."
      }]
    },
    {
      "code" : "RTO_PQ_PQ.denominator",
      "display" : "RTO_PQ_PQ.denominator",
      "target" : [{
        "code" : "Ratio.denominator",
        "display" : "Ratio.denominator",
        "equivalence" : "relatedto",
        "comment" : "Le dénominateur CDA est converti en Quantity via le mapping PQ -> Quantity, puis affecté à Ratio.denominator."
      }]
    }]
  }]
}

```
